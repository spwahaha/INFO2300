<?php 
// ** MySQL connection settings ** //

//Keep this as localhost for the course server
define('DB_HOST', 'localhost');

// Your course server username
define('DB_USER', 'your_server_username');    
 
// Your course server password
define('DB_PASSWORD', 'your_server_password'); 

// The name of the database to which you want to connect
// info230_SP14_username
define('DB_NAME', 'your_server_database_name');    
?>
