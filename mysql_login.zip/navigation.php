<a href="login-content1.php">Secret page 1 - SQL</a><br />
<a href="login-content2.php">Secret page 2 - SQL</a><br />
<a href="login-content3.php">Secret page 3 - SQL</a><br />
<a href="logout.php">Logout</a><br />
